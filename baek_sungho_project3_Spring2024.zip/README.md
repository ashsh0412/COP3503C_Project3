Name: Sungho Baek  
Section: 18713  
UFL email: sungho.baek@ufl.edu  
System: macOS  
Compiler: Apple Clang 16.0.0  
SFML version: 3.0.0  
IDE: CLion  
Other notes: If the project does not compile, please try downgrading Xcode to 16.2 version. Thank you, and have a great summer!